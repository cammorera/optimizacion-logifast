"""
solver.py
---------
Modelo de Programación Entera Mixta (MIP) para optimización
del centro Cross Docking de LogiFast CR.

MODELO MATEMÁTICO
=================

Conjuntos:
  I  = {1,...,n_i}   Camiones de entrada (inbound)
  J  = {1,...,n_o}   Camiones de salida  (outbound)
  K  = {1,...,n_k}   Tipos de producto

Parámetros:
  r[i][k]  = unidades del producto k que trae el camión i
  s[j][k]  = unidades del producto k que necesita el camión j
  t_unit   = tiempo de carga/descarga por unidad (minutos)
  t_trans  = tiempo de traslado interno por lote (minutos)
  t_chg    = tiempo de cambio entre camiones (minutos)

Variables de decisión:
  x[i,j,k]  ≥ 0  (continua)  Unidades del producto k transferidas del camión i al camión j
  y[i,j]    ∈ {0,1}  (binaria)  = 1 si algún producto se transfiere de i a j
  p_in[i,i']  ∈ {0,1}  (binaria)  = 1 si camión i precede a camión i' en secuencia de entrada
  p_out[j,j'] ∈ {0,1}  (binaria)  = 1 si camión j precede a camión j' en secuencia de salida
  a_in[i]    ≥ 0  (continua)  Tiempo de llegada/inicio de descarga del camión i
  d_in[i]    ≥ 0  (continua)  Tiempo de salida (fin de descarga) del camión i
  a_out[j]   ≥ 0  (continua)  Tiempo de inicio de carga del camión j
  d_out[j]   ≥ 0  (continua)  Tiempo de salida del camión j
  C          ≥ 0  (continua)  Makespan (tiempo total de operación)

Función objetivo:
  min C

Restricciones:
  (1)  C ≥ d_out[j]  ∀j ∈ J                    → makespan
  (2)  Σ_j x[i,j,k] = r[i][k]  ∀i,k            → toda oferta del camión i se distribuye
  (3)  Σ_i x[i,j,k] = s[j][k]  ∀j,k            → toda demanda del camión j es satisfecha
  (4)  x[i,j,k] ≤ min(r[i][k], s[j][k])*y[i,j] → vincula x con y
  (5-7) Secuencia camiones entrada (Big-M)
  (8)  p_in[i,i] = 0  ∀i                        → no auto-precedencia entrada
  (9-11) Secuencia camiones salida (Big-M)
  (12) p_out[j,j] = 0  ∀j                       → no auto-precedencia salida
  (13) a_out[j] ≥ d_in[i] - M*(1 - y[i,j])      → enlace entrada-salida
"""

import pulp
import pandas as pd
import numpy as np
from itertools import product as iterproduct


# ---------------------------------------------------------------------------
# Parámetros operativos (pueden sobreescribirse desde la interfaz)
# ---------------------------------------------------------------------------
DEFAULT_PARAMS = {
    't_unit': 1,    # minutos por unidad cargada/descargada
    't_trans': 5,   # minutos de traslado interno por lote
    't_chg': 10,    # minutos de cambio entre camiones
}

BIG_M = 100_000    # constante suficientemente grande


def compute_truck_times(data: dict, params: dict) -> dict:
    """
    Calcula el tiempo de descarga de cada camión de entrada
    y el tiempo de carga de cada camión de salida.
    """
    t_unit = params['t_unit']
    inbound_times = {}
    for i, prods in data['inbound'].items():
        total_units = sum(prods.values())
        inbound_times[i] = total_units * t_unit   # tiempo de descarga

    outbound_times = {}
    for j, prods in data['outbound'].items():
        total_units = sum(prods.values())
        outbound_times[j] = total_units * t_unit  # tiempo de carga

    return {'inbound': inbound_times, 'outbound': outbound_times}


def solve_crossdocking(data: dict, params: dict = None, time_limit: int = 120) -> dict:
    """
    Resuelve el modelo MIP de Cross Docking.

    Parámetros
    ----------
    data       : dict  retornado por parse_ts_content / parse_ts_file
    params     : dict  parámetros operativos (usa DEFAULT_PARAMS si None)
    time_limit : int   límite de tiempo en segundos para el solver

    Retorna
    -------
    dict con campos:
        status          : str
        makespan        : float  (minutos)
        inbound_order   : list   (secuencia óptima camiones entrada)
        outbound_order  : list   (secuencia óptima camiones salida)
        transfer_matrix : pd.DataFrame  (x[i,j,k] agrupado)
        truck_schedule  : dict   (tiempos de cada camión)
        via_storage     : dict   {(i,j): bool}  usa almacenamiento temporal?
        total_units_direct  : int
        total_units_storage : int
        solver_info     : dict
    """
    if params is None:
        params = DEFAULT_PARAMS.copy()

    t_unit  = params['t_unit']
    t_trans = params['t_trans']
    t_chg   = params['t_chg']

    I = list(data['inbound'].keys())    # camiones entrada
    J = list(data['outbound'].keys())   # camiones salida
    K = list(range(1, data['num_products'] + 1))

    r = data['inbound']   # r[i][k]
    s = data['outbound']  # s[j][k]

    truck_times = compute_truck_times(data, params)
    DT_in  = truck_times['inbound']   # tiempo descarga camión i
    DT_out = truck_times['outbound']  # tiempo carga camión j

    # -----------------------------------------------------------------------
    # Modelo
    # -----------------------------------------------------------------------
    prob = pulp.LpProblem("CrossDocking_LogiFast", pulp.LpMinimize)

    # ---- Variables de decisión ----

    # x[i,j,k]: unidades del producto k desde camión i hasta camión j
    x = {}
    for i in I:
        for j in J:
            for k in K:
                cap = min(r[i].get(k, 0), s[j].get(k, 0))
                x[i, j, k] = pulp.LpVariable(f"x_{i}_{j}_{k}", lowBound=0, upBound=cap)

    # y[i,j]: 1 si algún producto se transfiere de camión i a camión j
    y = {}
    for i in I:
        for j in J:
            y[i, j] = pulp.LpVariable(f"y_{i}_{j}", cat='Binary')

    # p_in[i,i']: 1 si camión de entrada i precede a i'
    p_in = {}
    for i in I:
        for ip in I:
            p_in[i, ip] = pulp.LpVariable(f"pin_{i}_{ip}", cat='Binary')

    # p_out[j,j']: 1 si camión de salida j precede a j'
    p_out = {}
    for j in J:
        for jp in J:
            p_out[j, jp] = pulp.LpVariable(f"pout_{j}_{jp}", cat='Binary')

    # Tiempos
    a_in  = {i: pulp.LpVariable(f"ain_{i}",  lowBound=0) for i in I}
    d_in  = {i: pulp.LpVariable(f"din_{i}",  lowBound=0) for i in I}
    a_out = {j: pulp.LpVariable(f"aout_{j}", lowBound=0) for j in J}
    d_out = {j: pulp.LpVariable(f"dout_{j}", lowBound=0) for j in J}

    # Makespan
    C = pulp.LpVariable("C", lowBound=0)

    # ---- Función objetivo ----
    prob += C, "Minimizar_Makespan"

    # ---- Restricciones ----

    # (1) Makespan ≥ tiempo de salida de todo camión de salida
    for j in J:
        prob += C >= d_out[j], f"makespan_{j}"

    # (2) Toda la oferta del camión i se distribuye a camiones de salida
    for i in I:
        for k in K:
            prob += (
                pulp.lpSum(x[i, j, k] for j in J) == r[i].get(k, 0),
                f"supply_{i}_{k}"
            )

    # (3) Toda la demanda del camión j es satisfecha desde camiones de entrada
    for j in J:
        for k in K:
            prob += (
                pulp.lpSum(x[i, j, k] for i in I) == s[j].get(k, 0),
                f"demand_{j}_{k}"
            )

    # (4) Vincula x con y: si y[i,j]=0 entonces x[i,j,k]=0 para todo k
    for i in I:
        for j in J:
            max_possible = sum(min(r[i].get(k, 0), s[j].get(k, 0)) for k in K)
            if max_possible > 0:
                prob += (
                    pulp.lpSum(x[i, j, k] for k in K) <= max_possible * y[i, j],
                    f"link_xy_{i}_{j}"
                )
            else:
                prob += y[i, j] == 0, f"zero_transfer_{i}_{j}"

    # (5-6) Tiempo de descarga del camión de entrada i
    for i in I:
        prob += d_in[i] == a_in[i] + DT_in[i], f"discharge_time_{i}"

    # (7) Secuencia camiones de entrada: si i precede a i', a_in[i'] ≥ d_in[i] + t_chg
    for i in I:
        for ip in I:
            if i != ip:
                prob += (
                    a_in[ip] >= d_in[i] + t_chg - BIG_M * (1 - p_in[i, ip]),
                    f"seq_in_{i}_{ip}"
                )

    # (8) No auto-precedencia entrada
    for i in I:
        prob += p_in[i, i] == 0, f"no_self_in_{i}"

    # (8b) Un par de camiones: uno debe preceder al otro (relación de orden total)
    for i in I:
        for ip in I:
            if i < ip:
                prob += p_in[i, ip] + p_in[ip, i] == 1, f"order_in_{i}_{ip}"

    # (9-10) Tiempo de carga del camión de salida j
    for j in J:
        prob += d_out[j] == a_out[j] + DT_out[j], f"load_time_{j}"

    # (11) Secuencia camiones de salida: si j precede a j', a_out[j'] ≥ d_out[j] + t_chg
    for j in J:
        for jp in J:
            if j != jp:
                prob += (
                    a_out[jp] >= d_out[j] + t_chg - BIG_M * (1 - p_out[j, jp]),
                    f"seq_out_{j}_{jp}"
                )

    # (12) No auto-precedencia salida
    for j in J:
        prob += p_out[j, j] == 0, f"no_self_out_{j}"

    # (12b) Un par de camiones de salida: uno debe preceder al otro
    for j in J:
        for jp in J:
            if j < jp:
                prob += p_out[j, jp] + p_out[jp, j] == 1, f"order_out_{j}_{jp}"

    # (13) Conecta salida del camión de entrada con inicio del camión de salida
    #      si hay transferencia directa (y[i,j]=1):
    #      a_out[j] ≥ d_in[i] + t_trans - M*(1 - y[i,j])
    for i in I:
        for j in J:
            prob += (
                a_out[j] >= d_in[i] + t_trans - BIG_M * (1 - y[i, j]),
                f"link_inout_{i}_{j}"
            )

    # -----------------------------------------------------------------------
    # Resolver
    # -----------------------------------------------------------------------
    solver = pulp.PULP_CBC_CMD(
        msg=0,
        timeLimit=time_limit,
        gapRel=0.01   # 1% gap de optimalidad
    )
    prob.solve(solver)

    status = pulp.LpStatus[prob.status]

    if prob.status not in (1, -2):  # 1=Optimal, -2=Not solved (feasible found)
        return {
            'status': status,
            'makespan': None,
            'error': f"Solver terminó con estado: {status}"
        }

    # -----------------------------------------------------------------------
    # Extraer resultados
    # -----------------------------------------------------------------------
    makespan_val = pulp.value(C)

    # Orden de camiones de entrada
    in_prec = {}
    for i in I:
        in_prec[i] = sum(
            round(pulp.value(p_in[ip, i]) or 0)
            for ip in I if ip != i
        )
    inbound_order = sorted(I, key=lambda i: in_prec[i])

    # Orden de camiones de salida
    out_prec = {}
    for j in J:
        out_prec[j] = sum(
            round(pulp.value(p_out[jp, j]) or 0)
            for jp in J if jp != j
        )
    outbound_order = sorted(J, key=lambda j: out_prec[j])

    # Tiempos de cada camión
    truck_schedule = {
        'inbound': {
            i: {
                'arrival': round(pulp.value(a_in[i]) or 0, 2),
                'departure': round(pulp.value(d_in[i]) or 0, 2),
                'unload_time': DT_in[i],
            }
            for i in I
        },
        'outbound': {
            j: {
                'arrival': round(pulp.value(a_out[j]) or 0, 2),
                'departure': round(pulp.value(d_out[j]) or 0, 2),
                'load_time': DT_out[j],
            }
            for j in J
        }
    }

    # Matriz de transferencias
    transfer_records = []
    via_storage = {}
    total_direct = 0
    total_storage = 0

    for i in I:
        for j in J:
            y_val = round(pulp.value(y[i, j]) or 0)
            for k in K:
                x_val = pulp.value(x[i, j, k]) or 0
                if x_val > 0.01:
                    # ¿Va por almacenamiento? Si el camión i termina ANTES de que
                    # j comience a cargar: puede ser directo. Si hay traslape,
                    # debe pasar por almacenamiento.
                    d_in_val  = pulp.value(d_in[i]) or 0
                    a_out_val = pulp.value(a_out[j]) or 0
                    storage = d_in_val > a_out_val + 0.1  # tolerancia numérica

                    via_storage[(i, j)] = storage

                    transfer_records.append({
                        'Camión Entrada': i,
                        'Camión Salida': j,
                        'Producto': k,
                        'Unidades': round(x_val),
                        'Ruta': 'Almacén Temporal' if storage else 'Directo',
                    })
                    if storage:
                        total_storage += round(x_val)
                    else:
                        total_direct += round(x_val)

    df_transfer = pd.DataFrame(transfer_records) if transfer_records else pd.DataFrame(
        columns=['Camión Entrada', 'Camión Salida', 'Producto', 'Unidades', 'Ruta']
    )

    # Info del solver
    solver_info = {
        'objective': round(pulp.value(prob.objective) or 0, 2),
        'num_variables': prob.numVariables(),
        'num_constraints': prob.numConstraints(),
        'solver': 'CBC (PuLP)',
    }

    return {
        'status': status,
        'makespan': round(makespan_val, 2),
        'inbound_order': inbound_order,
        'outbound_order': outbound_order,
        'truck_schedule': truck_schedule,
        'transfer_df': df_transfer,
        'via_storage': via_storage,
        'total_units_direct': total_direct,
        'total_units_storage': total_storage,
        'solver_info': solver_info,
        'params': params,
        'data': data,
    }


def summarize_results(results: dict) -> dict:
    """
    Genera resumen ejecutivo de los resultados para mostrar en la app.
    """
    if results.get('makespan') is None:
        return {}

    ts = results['truck_schedule']
    df = results['transfer_df']

    total_units = results['total_units_direct'] + results['total_units_storage']
    pct_direct  = (results['total_units_direct'] / total_units * 100) if total_units > 0 else 0
    pct_storage = (results['total_units_storage'] / total_units * 100) if total_units > 0 else 0

    # Tiempo de inactividad (idle) entre camiones de entrada
    in_sched = ts['inbound']
    out_sched = ts['outbound']

    in_order = results['inbound_order']
    out_order = results['outbound_order']

    idle_in = 0
    for idx in range(1, len(in_order)):
        prev = in_order[idx - 1]
        curr = in_order[idx]
        gap = in_sched[curr]['arrival'] - in_sched[prev]['departure']
        idle_in += max(0, gap)

    idle_out = 0
    for idx in range(1, len(out_order)):
        prev = out_order[idx - 1]
        curr = out_order[idx]
        gap = out_sched[curr]['arrival'] - out_sched[prev]['departure']
        idle_out += max(0, gap)

    return {
        'makespan_min': results['makespan'],
        'makespan_hr': round(results['makespan'] / 60, 2),
        'total_units': total_units,
        'pct_direct': round(pct_direct, 1),
        'pct_storage': round(pct_storage, 1),
        'idle_in': round(idle_in, 1),
        'idle_out': round(idle_out, 1),
        'num_transfers': len(df),
        'inbound_order': results['inbound_order'],
        'outbound_order': results['outbound_order'],
    }
