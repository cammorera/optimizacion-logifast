"""
app.py
------
Aplicación Streamlit para optimización del Cross Docking - LogiFast CR
Universidad de Costa Rica | Ingeniería Industrial | Semestre I 2026
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from io import StringIO
import time

from utils.parser import parse_ts_content, build_supply_demand_matrix, validate_data
from solver import solve_crossdocking, summarize_results, DEFAULT_PARAMS

# ─────────────────────────────────────────────────────────────────────────────
# Configuración de página
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="LogiFast CR — Optimización Cross Docking",
    page_icon="🚛",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
# CSS personalizado
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Tipografía y fondo */
    html, body, [class*="css"] {
        font-family: 'Inter', 'Segoe UI', sans-serif;
        background-color: #f8f9fa;
        color: #1a1a2e;
    }

    /* Header principal */
    .main-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        color: white;
        padding: 2rem 2.5rem;
        border-radius: 16px;
        margin-bottom: 2rem;
        box-shadow: 0 8px 32px rgba(31,38,135,0.15);
    }
    .main-header h1 { margin: 0; font-size: 2rem; font-weight: 700; }
    .main-header p  { margin: 0.4rem 0 0; opacity: 0.85; font-size: 1rem; }

    /* Tarjetas de métricas */
    .metric-card {
        background: white;
        border-radius: 12px;
        padding: 1.2rem 1.5rem;
        box-shadow: 0 2px 12px rgba(0,0,0,0.07);
        border-left: 4px solid #0f3460;
        margin-bottom: 1rem;
    }
    .metric-card .label { font-size: 0.8rem; color: #6c757d; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }
    .metric-card .value { font-size: 2rem; font-weight: 700; color: #0f3460; line-height: 1.2; }
    .metric-card .unit  { font-size: 0.85rem; color: #495057; }

    /* Sección con tarjeta */
    .section-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 2px 12px rgba(0,0,0,0.07);
        margin-bottom: 1.5rem;
    }

    /* Badges */
    .badge-direct  { background:#d4edda; color:#155724; padding:3px 10px; border-radius:20px; font-size:0.8rem; font-weight:600; }
    .badge-storage { background:#fff3cd; color:#856404; padding:3px 10px; border-radius:20px; font-size:0.8rem; font-weight:600; }

    /* Ecuaciones matemáticas */
    .math-box {
        background: #f0f4ff;
        border: 1px solid #d0d9ff;
        border-radius: 8px;
        padding: 1rem 1.2rem;
        font-family: 'Courier New', monospace;
        font-size: 0.92rem;
        margin: 0.5rem 0;
        color: #1a1a2e;
    }

    /* Sidebar */
    [data-testid="stSidebar"] {
        background: white;
        border-right: 1px solid #e9ecef;
    }

    /* Botón primario */
    .stButton > button {
        background: linear-gradient(135deg, #0f3460, #16213e);
        color: white;
        border: none;
        padding: 0.6rem 2rem;
        border-radius: 8px;
        font-weight: 600;
        font-size: 1rem;
        width: 100%;
        transition: opacity 0.2s;
    }
    .stButton > button:hover { opacity: 0.88; }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] { gap: 4px; }
    .stTabs [data-baseweb="tab"] {
        background: #f1f3f5;
        border-radius: 8px 8px 0 0;
        padding: 0.5rem 1.2rem;
        font-weight: 500;
    }
    .stTabs [aria-selected="true"] { background: white; }

    /* Divider */
    hr { border-color: #e9ecef; margin: 1.5rem 0; }

    /* Alertas personalizadas */
    .info-box {
        background: #e8f4fd;
        border-left: 4px solid #1a73e8;
        padding: 0.8rem 1.2rem;
        border-radius: 0 8px 8px 0;
        margin: 0.8rem 0;
        font-size: 0.9rem;
        color: #174ea6;
    }
    .success-box {
        background: #e6f4ea;
        border-left: 4px solid #34a853;
        padding: 0.8rem 1.2rem;
        border-radius: 0 8px 8px 0;
        margin: 0.8rem 0;
        font-size: 0.9rem;
        color: #137333;
    }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>🚛 LogiFast CR — Optimización Cross Docking</h1>
    <p>Modelo de Programación Entera Mixta (MIP) | Universidad de Costa Rica · Ingeniería Industrial · I Semestre 2026</p>
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Sidebar — Parámetros & carga de datos
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 📂 Datos de Operación")
    st.markdown("Cargue un archivo TS en formato `.txt` o use los datos de ejemplo (TS5).")

    uploaded_file = st.file_uploader("Archivo TS (.txt)", type=["txt"])

    use_example = st.checkbox("Usar datos de ejemplo (TS5)", value=(uploaded_file is None))

    st.markdown("---")
    st.markdown("### ⚙️ Parámetros Operativos")

    t_unit  = st.number_input("Tiempo por unidad (min)", min_value=0.5, max_value=10.0, value=1.0, step=0.5,
                               help="Minutos requeridos para cargar o descargar una unidad de producto")
    t_trans = st.number_input("Tiempo traslado interno (min)", min_value=1.0, max_value=30.0, value=5.0, step=1.0,
                               help="Minutos de traslado interno por lote entre muelles")
    t_chg   = st.number_input("Tiempo cambio de camión (min)", min_value=1.0, max_value=30.0, value=10.0, step=1.0,
                               help="Tiempo de preparación/cambio entre dos camiones consecutivos en un muelle")

    st.markdown("---")
    st.markdown("### 🔧 Configuración Solver")
    time_limit = st.slider("Límite de tiempo (seg)", 30, 300, 120, 10,
                            help="Tiempo máximo que tiene el solver para encontrar la solución óptima")
    gap_pct = st.slider("Gap de optimalidad (%)", 0, 10, 1, 1,
                         help="Porcentaje de tolerancia respecto al óptimo global")

    st.markdown("---")
    run_btn = st.button("▶ Ejecutar Optimización", use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# Cargar y parsear datos
# ─────────────────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_example_data():
    with open("data/TS5.txt", "r") as f:
        return f.read()


def load_data(uploaded_file, use_example):
    if uploaded_file is not None:
        return uploaded_file.read().decode("utf-8")
    if use_example:
        return load_example_data()
    return None


raw_content = load_data(uploaded_file, use_example)

if raw_content is None:
    st.info("⬅️ Por favor cargue un archivo TS o active la opción de datos de ejemplo.")
    st.stop()

try:
    data = parse_ts_content(raw_content)
except Exception as e:
    st.error(f"Error al parsear el archivo: {e}")
    st.stop()

warnings = validate_data(data)

# ─────────────────────────────────────────────────────────────────────────────
# Tabs principales
# ─────────────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📋 Caso & Modelo",
    "📊 Datos de Entrada",
    "🔍 Solución Óptima",
    "📈 Visualizaciones",
    "📝 Conclusiones",
])

# ═══════════════════════════════════════════════════════════════════════════
# TAB 1 — CASO & MODELO MATEMÁTICO
# ═══════════════════════════════════════════════════════════════════════════
with tab1:
    col_a, col_b = st.columns([1, 1])

    with col_a:
        st.markdown("## 🏭 Descripción del Caso")
        st.markdown("""
        **LogiFast CR** opera un centro de distribución tipo *Cross Docking* en el Valle Central 
        de Costa Rica para abastecer tiendas minoristas. Los productos recibidos de proveedores 
        se transfieren directamente (o con mínimo almacenamiento) a camiones de salida con destino 
        a clientes.

        **Reto operativo:** determinar el **orden óptimo** de atención de camiones de entrada 
        y salida para completar todas las operaciones en el **menor tiempo posible**.

        #### Estructura del Centro
        | Elemento | Detalle |
        |---|---|
        | Muelles de entrada | 1 |
        | Muelles de salida  | 1 |
        | Almacenamiento temporal | Disponible (ilimitado, pero costoso en tiempo) |
        | Carga/Descarga simultánea | ✅ Permitida |
        | Carga mixta (directo + almacén simultáneo) | ❌ No permitida |

        #### Preguntas Clave
        1. ¿Qué decisiones debe tomar la empresa para organizar la operación?
        2. ¿Qué se busca optimizar en el sistema?
        3. ¿Cómo se expresan las variables de decisión y restricciones como MIP?
        """)

    with col_b:
        st.markdown("## 🧮 Modelo Matemático")

        st.markdown("#### Conjuntos")
        st.markdown("""
        <div class="math-box">
        I = {1,...,n_i}   Camiones de entrada (inbound)<br>
        J = {1,...,n_o}   Camiones de salida  (outbound)<br>
        K = {1,...,n_k}   Tipos de producto
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### Parámetros")
        st.markdown("""
        <div class="math-box">
        r[i][k]  = unidades del producto k en camión de entrada i<br>
        s[j][k]  = unidades del producto k requeridas por camión j<br>
        t_unit   = tiempo de carga/descarga por unidad (min)<br>
        t_trans  = tiempo de traslado interno por lote (min)<br>
        t_chg    = tiempo de cambio entre camiones (min)
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### Variables de Decisión")
        st.markdown("""
        | Variable | Tipo | Descripción |
        |---|---|---|
        | x[i,j,k] | Continua ≥ 0 | Unidades de producto k de camión i a camión j |
        | y[i,j] | Binaria {0,1} | 1 si hay transferencia del camión i al camión j |
        | p_in[i,i'] | Binaria {0,1} | 1 si camión i precede a i' en entrada |
        | p_out[j,j'] | Binaria {0,1} | 1 si camión j precede a j' en salida |
        | a_in[i] | Continua ≥ 0 | Tiempo de inicio de descarga del camión i |
        | d_in[i] | Continua ≥ 0 | Tiempo de fin de descarga del camión i |
        | a_out[j] | Continua ≥ 0 | Tiempo de inicio de carga del camión j |
        | d_out[j] | Continua ≥ 0 | Tiempo de fin de carga del camión j |
        | C | Continua ≥ 0 | Makespan (tiempo total de operación) |
        """)

        st.markdown("#### Función Objetivo")
        st.markdown("""
        <div class="math-box">
        <strong>min  C</strong>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### Restricciones Principales (13)")
        restricciones = [
            ("(1) Makespan", "C ≥ d_out[j]  ∀j ∈ J"),
            ("(2) Balance oferta entrada", "Σ_j x[i,j,k] = r[i][k]  ∀i, k"),
            ("(3) Balance demanda salida", "Σ_i x[i,j,k] = s[j][k]  ∀j, k"),
            ("(4) Vinculación x con y", "Σ_k x[i,j,k] ≤ M·y[i,j]  ∀i,j"),
            ("(5-6) Tiempo descarga", "d_in[i] = a_in[i] + DT_in[i]  ∀i"),
            ("(7) Secuencia entrada", "a_in[i'] ≥ d_in[i] + t_chg - M(1-p_in[i,i'])  ∀i≠i'"),
            ("(8) No auto-precedencia entrada", "p_in[i,i] = 0  ∀i"),
            ("(9-10) Tiempo carga", "d_out[j] = a_out[j] + DT_out[j]  ∀j"),
            ("(11) Secuencia salida", "a_out[j'] ≥ d_out[j] + t_chg - M(1-p_out[j,j'])  ∀j≠j'"),
            ("(12) No auto-precedencia salida", "p_out[j,j] = 0  ∀j"),
            ("(13) Enlace entrada-salida", "a_out[j] ≥ d_in[i] + t_trans - M(1-y[i,j])  ∀i,j"),
        ]
        for nombre, formula in restricciones:
            st.markdown(f"**{nombre}**")
            st.markdown(f'<div class="math-box">{formula}</div>', unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════
# TAB 2 — DATOS DE ENTRADA
# ═══════════════════════════════════════════════════════════════════════════
with tab2:
    st.markdown("## 📊 Datos del Archivo TS")

    if warnings:
        for w in warnings:
            st.warning(w)

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">Camiones de Entrada</div>
            <div class="value">{data['num_inbound']}</div>
            <div class="unit">inbound trucks</div>
        </div>""", unsafe_allow_html=True)
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">Camiones de Salida</div>
            <div class="value">{data['num_outbound']}</div>
            <div class="unit">outbound trucks</div>
        </div>""", unsafe_allow_html=True)
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">Tipos de Producto</div>
            <div class="value">{data['num_products']}</div>
            <div class="unit">product types</div>
        </div>""", unsafe_allow_html=True)

    supply_df, demand_df = build_supply_demand_matrix(data)

    col_s, col_d = st.columns(2)
    with col_s:
        st.markdown("### 📥 Matriz de Oferta (Camiones de Entrada)")
        st.markdown("*Unidades por producto en cada camión de entrada*")
        supply_display = supply_df.copy()
        supply_display.columns = [f"Prod {c}" for c in supply_display.columns]
        supply_display.index = [f"Camión E{i}" for i in supply_display.index]
        supply_display['**Total**'] = supply_display.sum(axis=1)
        st.dataframe(supply_display, use_container_width=True)

    with col_d:
        st.markdown("### 📤 Matriz de Demanda (Camiones de Salida)")
        st.markdown("*Unidades requeridas por producto en cada camión de salida*")
        demand_display = demand_df.copy()
        demand_display.columns = [f"Prod {c}" for c in demand_display.columns]
        demand_display.index = [f"Camión S{j}" for j in demand_display.index]
        demand_display['**Total**'] = demand_display.sum(axis=1)
        st.dataframe(demand_display, use_container_width=True)

    st.markdown("---")
    st.markdown("### 🔄 Balance por Producto")
    products = list(range(1, data['num_products'] + 1))
    balance_rows = []
    for k in products:
        sup = sum(data['inbound'][i].get(k, 0) for i in data['inbound'])
        dem = sum(data['outbound'][j].get(k, 0) for j in data['outbound'])
        balance_rows.append({'Producto': f"Producto {k}", 'Oferta Total': sup, 'Demanda Total': dem, 'Balance': sup - dem})
    balance_df = pd.DataFrame(balance_rows)

    fig_bal = px.bar(
        balance_df.melt(id_vars='Producto', value_vars=['Oferta Total', 'Demanda Total']),
        x='Producto', y='value', color='variable', barmode='group',
        color_discrete_map={'Oferta Total': '#0f3460', 'Demanda Total': '#e94560'},
        labels={'value': 'Unidades', 'variable': ''},
        title='Oferta vs Demanda por Producto',
        height=320,
    )
    fig_bal.update_layout(
        plot_bgcolor='white', paper_bgcolor='white',
        font_color='#1a1a2e', title_font_size=14,
        legend=dict(orientation='h', y=1.1)
    )
    st.plotly_chart(fig_bal, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════
# TAB 3 — SOLUCIÓN ÓPTIMA
# ═══════════════════════════════════════════════════════════════════════════
with tab3:
    if not run_btn and 'results' not in st.session_state:
        st.markdown("""
        <div class="info-box">
            ℹ️ Haga clic en <strong>▶ Ejecutar Optimización</strong> en el panel lateral para obtener la solución óptima.
        </div>
        """, unsafe_allow_html=True)
        st.stop()

    if run_btn:
        params = {
            't_unit':  t_unit,
            't_trans': t_trans,
            't_chg':   t_chg,
        }
        with st.spinner("⏳ Resolviendo el modelo MIP... esto puede tomar algunos segundos."):
            t0 = time.time()
            results = solve_crossdocking(data, params, time_limit=time_limit)
            elapsed = round(time.time() - t0, 1)
        st.session_state['results'] = results
        st.session_state['elapsed'] = elapsed
    else:
        results = st.session_state['results']
        elapsed = st.session_state.get('elapsed', '—')

    if results.get('makespan') is None:
        st.error(f"❌ El solver no encontró solución factible: {results.get('error', 'Error desconocido')}")
        st.stop()

    summary = summarize_results(results)

    # ── Estado del solver ──
    st.markdown(f"""
    <div class="success-box">
        ✅ Solución encontrada en <strong>{elapsed}s</strong> &nbsp;|&nbsp; 
        Estado: <strong>{results['status']}</strong> &nbsp;|&nbsp;
        Variables: {results['solver_info']['num_variables']} &nbsp;|&nbsp;
        Restricciones: {results['solver_info']['num_constraints']}
    </div>
    """, unsafe_allow_html=True)

    # ── Métricas principales ──
    st.markdown("### 📌 Indicadores Clave")
    m1, m2, m3, m4 = st.columns(4)

    with m1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">⏱ Makespan Total</div>
            <div class="value">{summary['makespan_min']}</div>
            <div class="unit">minutos ({summary['makespan_hr']} horas)</div>
        </div>""", unsafe_allow_html=True)
    with m2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">📦 Unidades Totales</div>
            <div class="value">{summary['total_units']}</div>
            <div class="unit">unidades procesadas</div>
        </div>""", unsafe_allow_html=True)
    with m3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">⚡ Flujo Directo</div>
            <div class="value">{summary['pct_direct']}%</div>
            <div class="unit">{results['total_units_direct']} unidades directas</div>
        </div>""", unsafe_allow_html=True)
    with m4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="label">🏪 Vía Almacén</div>
            <div class="value">{summary['pct_storage']}%</div>
            <div class="unit">{results['total_units_storage']} unidades en almacén</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("---")

    # ── Secuencia óptima ──
    col_seq1, col_seq2 = st.columns(2)

    with col_seq1:
        st.markdown("### 📥 Secuencia Óptima — Camiones de Entrada")
        in_order = results['inbound_order']
        in_sched = results['truck_schedule']['inbound']
        seq_in_rows = []
        for pos, i in enumerate(in_order, 1):
            seq_in_rows.append({
                'Posición': pos,
                'Camión': f"Camión E{i}",
                'Inicio descarga (min)': in_sched[i]['arrival'],
                'Fin descarga (min)': in_sched[i]['departure'],
                'Tiempo descarga (min)': in_sched[i]['unload_time'],
            })
        st.dataframe(pd.DataFrame(seq_in_rows), use_container_width=True, hide_index=True)

    with col_seq2:
        st.markdown("### 📤 Secuencia Óptima — Camiones de Salida")
        out_order = results['outbound_order']
        out_sched = results['truck_schedule']['outbound']
        seq_out_rows = []
        for pos, j in enumerate(out_order, 1):
            seq_out_rows.append({
                'Posición': pos,
                'Camión': f"Camión S{j}",
                'Inicio carga (min)': out_sched[j]['arrival'],
                'Fin carga (min)': out_sched[j]['departure'],
                'Tiempo carga (min)': out_sched[j]['load_time'],
            })
        st.dataframe(pd.DataFrame(seq_out_rows), use_container_width=True, hide_index=True)

    st.markdown("---")

    # ── Matriz de transferencias ──
    st.markdown("### 🔄 Plan de Transferencias (x[i,j,k])")
    df_t = results['transfer_df'].copy()
    if not df_t.empty:
        df_t['Camión Entrada'] = df_t['Camión Entrada'].apply(lambda x: f"E{x}")
        df_t['Camión Salida']  = df_t['Camión Salida'].apply(lambda x: f"S{x}")
        df_t['Producto']       = df_t['Producto'].apply(lambda x: f"Prod {x}")

        def style_ruta(val):
            if val == 'Directo':
                return 'background-color:#d4edda; color:#155724; font-weight:600'
            return 'background-color:#fff3cd; color:#856404; font-weight:600'

        styled = df_t.style.applymap(style_ruta, subset=['Ruta'])
        st.dataframe(styled, use_container_width=True, hide_index=True)
    else:
        st.info("No se generaron transferencias.")


# ═══════════════════════════════════════════════════════════════════════════
# TAB 4 — VISUALIZACIONES
# ═══════════════════════════════════════════════════════════════════════════
with tab4:
    if 'results' not in st.session_state:
        st.info("⬅️ Ejecute la optimización primero.")
        st.stop()

    results = st.session_state['results']

    # ── Diagrama de Gantt ──
    st.markdown("### 📅 Diagrama de Gantt — Programación de Camiones")

    gantt_data = []
    in_sched  = results['truck_schedule']['inbound']
    out_sched = results['truck_schedule']['outbound']
    in_order  = results['inbound_order']
    out_order = results['outbound_order']

    for i in in_order:
        gantt_data.append(dict(
            Task=f"Muelle Entrada",
            Start=in_sched[i]['arrival'],
            Finish=in_sched[i]['departure'],
            Resource=f"Camión E{i}",
            Type="Entrada",
        ))
    for j in out_order:
        gantt_data.append(dict(
            Task=f"Muelle Salida",
            Start=out_sched[j]['arrival'],
            Finish=out_sched[j]['departure'],
            Resource=f"Camión S{j}",
            Type="Salida",
        ))

    palette = {
        **{f"Camión E{i}": px.colors.qualitative.Bold[idx % 10] for idx, i in enumerate(in_order)},
        **{f"Camión S{j}": px.colors.qualitative.Pastel[idx % 10] for idx, j in enumerate(out_order)},
    }

    fig_gantt = go.Figure()
    y_labels = ["Muelle Entrada", "Muelle Salida"]

    for row in gantt_data:
        y_idx = y_labels.index(row['Task'])
        fig_gantt.add_trace(go.Bar(
            x=[row['Finish'] - row['Start']],
            y=[row['Task']],
            base=[row['Start']],
            orientation='h',
            name=row['Resource'],
            marker_color=palette.get(row['Resource'], '#888'),
            text=row['Resource'],
            textposition='inside',
            insidetextanchor='middle',
            hovertemplate=f"<b>{row['Resource']}</b><br>Inicio: {row['Start']} min<br>Fin: {row['Finish']} min<extra></extra>",
        ))

    fig_gantt.update_layout(
        barmode='stack',
        height=280,
        xaxis=dict(title='Tiempo (minutos)', showgrid=True, gridcolor='#e9ecef'),
        yaxis=dict(title='', categoryorder='array', categoryarray=y_labels),
        plot_bgcolor='white', paper_bgcolor='white',
        font_color='#1a1a2e',
        legend=dict(orientation='h', y=-0.25, title='Camiones'),
        title='Programación de Camiones en Muelles',
        title_font_size=14,
        showlegend=True,
    )
    # Línea de makespan
    fig_gantt.add_vline(
        x=results['makespan'], line_dash='dash', line_color='#e94560',
        annotation_text=f"  Makespan: {results['makespan']} min",
        annotation_font_color='#e94560',
    )
    st.plotly_chart(fig_gantt, use_container_width=True)

    st.markdown("---")

    col_v1, col_v2 = st.columns(2)

    with col_v1:
        # ── Flujo directo vs almacén ──
        st.markdown("### 📦 Flujo de Unidades")
        fig_pie = go.Figure(go.Pie(
            labels=['Flujo Directo', 'Vía Almacén Temporal'],
            values=[results['total_units_direct'], results['total_units_storage']],
            hole=0.5,
            marker_colors=['#0f3460', '#e94560'],
            textinfo='label+percent',
            textfont_size=13,
        ))
        fig_pie.update_layout(
            height=320,
            plot_bgcolor='white', paper_bgcolor='white',
            font_color='#1a1a2e',
            title='Distribución del Flujo de Productos',
            title_font_size=13,
            showlegend=False,
        )
        st.plotly_chart(fig_pie, use_container_width=True)

    with col_v2:
        # ── Carga por camión de entrada ──
        st.markdown("### 🔢 Unidades por Camión de Entrada")
        in_totals = {i: sum(data['inbound'][i].values()) for i in data['inbound']}
        fig_bar_in = go.Figure(go.Bar(
            x=[f"E{i}" for i in in_totals],
            y=list(in_totals.values()),
            marker_color='#0f3460',
            text=list(in_totals.values()),
            textposition='outside',
        ))
        fig_bar_in.update_layout(
            height=320,
            xaxis_title='Camión de Entrada',
            yaxis_title='Unidades',
            plot_bgcolor='white', paper_bgcolor='white',
            font_color='#1a1a2e',
            title='Carga Total por Camión de Entrada',
            title_font_size=13,
        )
        st.plotly_chart(fig_bar_in, use_container_width=True)

    st.markdown("---")

    # ── Heatmap de transferencias ──
    st.markdown("### 🗺️ Mapa de Calor — Transferencias x[i,j]")
    df_heat = results['transfer_df']
    if not df_heat.empty:
        pivot = df_heat.groupby(['Camión Entrada', 'Camión Salida'])['Unidades'].sum().reset_index()
        pivot_table = pivot.pivot(index='Camión Entrada', columns='Camión Salida', values='Unidades').fillna(0)

        fig_heat = px.imshow(
            pivot_table,
            labels=dict(x="Camión de Salida", y="Camión de Entrada", color="Unidades"),
            color_continuous_scale='Blues',
            text_auto=True,
            title='Total de Unidades Transferidas entre Camiones (suma de todos los productos)',
            height=300,
        )
        fig_heat.update_layout(
            plot_bgcolor='white', paper_bgcolor='white',
            font_color='#1a1a2e', title_font_size=13,
        )
        fig_heat.update_xaxes(tickprefix="S")
        fig_heat.update_yaxes(tickprefix="E")
        st.plotly_chart(fig_heat, use_container_width=True)

    # ── Carga por camión de salida ──
    st.markdown("### 🔢 Unidades por Camión de Salida")
    out_totals = {j: sum(data['outbound'][j].values()) for j in data['outbound']}
    fig_bar_out = go.Figure(go.Bar(
        x=[f"S{j}" for j in out_totals],
        y=list(out_totals.values()),
        marker_color='#e94560',
        text=list(out_totals.values()),
        textposition='outside',
    ))
    fig_bar_out.update_layout(
        height=280,
        xaxis_title='Camión de Salida',
        yaxis_title='Unidades',
        plot_bgcolor='white', paper_bgcolor='white',
        font_color='#1a1a2e',
        title='Carga Total por Camión de Salida',
        title_font_size=13,
    )
    st.plotly_chart(fig_bar_out, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════
# TAB 5 — CONCLUSIONES
# ═══════════════════════════════════════════════════════════════════════════
with tab5:
    if 'results' not in st.session_state:
        st.info("⬅️ Ejecute la optimización primero.")
        st.stop()

    results = st.session_state['results']
    summary = summarize_results(results)

    st.markdown("## 📝 Interpretación Operativa de la Solución")

    # Conclusión dinámica automática
    in_seq  = " → ".join([f"E{i}" for i in summary['inbound_order']])
    out_seq = " → ".join([f"S{j}" for j in summary['outbound_order']])

    direct_comment = (
        "la mayoría del flujo es directo, lo que reduce significativamente el uso del almacén temporal."
        if summary['pct_direct'] >= 60
        else "una fracción importante del flujo pasa por almacén temporal, lo que aumenta el tiempo de operación."
    )

    st.markdown(f"""
    <div class="section-card">
    <h4>🎯 Resumen de la Solución Óptima</h4>

    El modelo MIP encontró una secuencia de atención que permite completar todas las operaciones 
    del centro Cross Docking de <strong>LogiFast CR</strong> en un tiempo total 
    (<em>makespan</em>) de <strong>{summary['makespan_min']} minutos 
    ({summary['makespan_hr']} horas)</strong>.

    <br><br>

    <strong>Secuencia óptima de entrada:</strong> {in_seq}<br>
    <strong>Secuencia óptima de salida:</strong> {out_seq}

    <br><br>

    En cuanto al flujo de productos, {direct_comment}
    De las <strong>{summary['total_units']}</strong> unidades totales procesadas:
    <ul>
        <li>🟢 <strong>{results['total_units_direct']}</strong> unidades 
            (<strong>{summary['pct_direct']}%</strong>) se transfirieron directamente del muelle de 
            entrada al de salida.</li>
        <li>🟡 <strong>{results['total_units_storage']}</strong> unidades 
            (<strong>{summary['pct_storage']}%</strong>) pasaron por el almacén temporal antes de 
            cargarse al camión de salida correspondiente.</li>
    </ul>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    col_c1, col_c2 = st.columns(2)

    with col_c1:
        st.markdown("""
        <div class="section-card">
        <h4>💡 Decisiones Clave del Modelo</h4>
        <ul>
            <li><strong>Secuenciación:</strong> El orden en que se atienden los camiones de entrada 
            y salida determina en gran medida el makespan. Una mala coordinación puede generar 
            tiempos muertos innecesarios en los muelles.</li>
            <li><strong>Asignación de productos:</strong> Las variables x[i,j,k] deciden cuántas 
            unidades de cada producto fluyen de cada camión de entrada a cada camión de salida.</li>
            <li><strong>Almacenamiento temporal:</strong> La decisión de si un producto espera 
            en almacén o va directo surge implícitamente de la temporización de los camiones.</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)

    with col_c2:
        st.markdown("""
        <div class="section-card">
        <h4>⚠️ Factores que Impactan el Makespan</h4>
        <ul>
            <li><strong>Tiempo de cambio de camión:</strong> Cada transición entre camiones en 
            el mismo muelle cuesta 10 minutos. Minimizar interrupciones es clave.</li>
            <li><strong>Tiempo de traslado:</strong> Cuando un producto debe pasar por almacén 
            temporal, se agrega un tiempo de traslado interno de 5 minutos por lote.</li>
            <li><strong>Heterogeneidad de carga:</strong> Camiones con muchos productos distintos 
            generan mayor complejidad en la coordinación de transferencias.</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("""
    <div class="section-card">
    <h4>📊 Indicadores de Eficiencia Operativa</h4>
    """, unsafe_allow_html=True)

    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Makespan", f"{summary['makespan_min']} min", help="Tiempo total de operación del almacén")
    with c2:
        st.metric("% Flujo Directo", f"{summary['pct_direct']}%", help="Porcentaje de unidades que van directo sin pasar por almacén")
    with c3:
        st.metric("Transfers planificadas", summary['num_transfers'], help="Número de movimientos de producto entre pares de camiones")

    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("""
    <div class="section-card">
    <h4>🔧 Recomendaciones Operativas</h4>
    <ol>
        <li>Seguir estrictamente la <strong>secuencia óptima</strong> de camiones calculada por el modelo.</li>
        <li>Preparar el área de almacenamiento temporal para los lotes que no pueden ir directamente.</li>
        <li>Coordinar con proveedores para garantizar la disponibilidad de todos los camiones desde el inicio.</li>
        <li>Monitorear los tiempos de cambio entre camiones: retrasos aquí se propagan a todo el makespan.</li>
        <li>Revisar periódicamente con datos reales si los supuestos de tiempos siguen siendo válidos.</li>
    </ol>
    </div>
    """, unsafe_allow_html=True)

    # ── Supuestos del modelo ──
    st.markdown("""
    <div class="section-card">
    <h4>📌 Supuestos del Modelo</h4>
    <ul>
        <li>Todos los camiones están disponibles desde el minuto 0.</li>
        <li>El almacenamiento temporal tiene capacidad ilimitada (solo penaliza en tiempo).</li>
        <li>Las operaciones de carga y descarga pueden realizarse simultáneamente en ambos muelles.</li>
        <li>No se permite carga simultánea desde el muelle de entrada y desde almacén temporal hacia 
        un mismo camión de salida.</li>
        <li>El tiempo de traslado de almacén temporal se aplica una sola vez por par (camión entrada, 
        camión salida).</li>
        <li>No hay prioridad de clientes.</li>
    </ul>
    </div>
    """, unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Footer
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<hr>
<p style="text-align:center; color:#6c757d; font-size:0.85rem;">
    LogiFast CR · Optimización Cross Docking · Universidad de Costa Rica · I Semestre 2026<br>
    Desarrollado con Streamlit + PuLP (CBC Solver)
</p>
""", unsafe_allow_html=True)
